<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<h3>menu do site.</h3>";
?>
<nav>
    <ul>
        <li><a href="index.php"> Home </a></li>
        <li><a href="?pg=quemsomos"> Quem Somos </a></li>
        <li><a href="?pg=admin/clientes-admin"> Clientes </a></li>
        <li><a href="?pg=admin/enderecos-admin"> Endereços de Entrega </a></li>
        <li><a href="?pg=faleconosco"> Contato </a></li>
    </ul>
</nav>
