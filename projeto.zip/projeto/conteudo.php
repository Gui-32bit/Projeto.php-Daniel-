<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<h2>Conteúdo do site.</h2>";
