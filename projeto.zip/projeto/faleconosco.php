<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php
    echo "<h3>Fale Conosco</h3>";
    echo "<p>Um parágrafo de texto qualquer.</p>";
