<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<h3>Rodapé do site.</h3>";
?>
</body>
</html>