<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<p style='color: rgb(255, 255, 255)';>Autor:Guilherme de Queiroz Nunes</p>";
?></div>
</body>
</html>