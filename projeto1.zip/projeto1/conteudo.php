<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<h3 style='color: rgb(231, 217, 19)'>Aqui você podera fazer o cadastro do nosso site <br> e receber <strong> beneficios exclusivos</strong><br><br>Clique na aba de <strong>Clientes</strong> para Fazer o cadastro no nosso site<br></h3>";
