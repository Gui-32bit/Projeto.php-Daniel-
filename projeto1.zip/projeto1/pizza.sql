-- Banco de dados para Projeto 1
CREATE DATABASE IF NOT EXISTS _projeto_1;
USE pizza;

-- Tabela clientes (modelo mínimo compatível com o projeto existente)
CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente VARCHAR(255) NOT NULL,
  cidade VARCHAR(100),
  estado VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Nova tabela: pizzas
CREATE TABLE IF NOT EXISTS pizzas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tamanho INT NOT NULL,
  sabor VARCHAR(255) NOT NULL

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
