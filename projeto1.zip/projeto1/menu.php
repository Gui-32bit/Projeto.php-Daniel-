<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php

    echo "<h3>Pizzaria boa massa.</h3>";
?>
<nav>
    <ul>
        <li><a href="index.php"> Home </a></li>
        <li><a href="?pg=quemsomos"> Quem Somos </a></li>
        <li><a href="?pg=admin/clientes-admin"> Clientes </a></li>
        <li><a href="?pg=admin/pizza-admin"> Pizzas </a></li>
        <li><a href="?pg=faleconosco"> Contato </a></li>
    </ul>
</nav>
