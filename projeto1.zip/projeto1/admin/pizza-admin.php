<?php echo '<link rel="stylesheet" href="../style.css">'; ?>
<?php
require "config.inc.php";

echo "<h2>Pizzas</h2>";
echo "<p><a href='?pg=admin/pizza-cadastro-form'>Cadastrar novo endereço</a></p>";

// Listar endereços com nome do cliente
$sql = "SELECT * FROM pizzas";
$res = mysqli_query($conexao, $sql);

if(mysqli_num_rows($res) > 0){
    while($dados = mysqli_fetch_assoc($res)){
        echo "<strong>ID:</strong> " . $dados['id'] . "<br>";
        echo "<strong>Sabor:</strong> " . $dados['sabor'] . "<br>";
        echo "<strong>Tamanho:</strong> " . $dados['tamanho'] . "<br>";
        echo "<a href='?pg=admin/pizza-altera-form&id={$dados['id']}'>Editar</a> | ";
        echo "<a href='?pg=admin/pizza-excluir&id={$dados['id']}' onclick=\"return confirm('Confirma exclusão do endereço ID {$dados['id']}?')\">Excluir</a>";
        echo "<hr>";
    }
}else{
    echo "<p>Nenhuma pizza cadastrada.</p>";
}
?>
