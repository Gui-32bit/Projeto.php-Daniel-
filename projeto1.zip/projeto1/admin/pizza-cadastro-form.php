<?php echo '<link rel="stylesheet" href="../style.css">'; ?>
<div>
    <h2>Cadastrar Pizza para entrega</h2>
    <form action="?pg=admin/pizza-cadastro" method="post">
        <label> Tamanho:</label>
        <input type="number" name="tamanho" required><br>
        <label> Sabor:</label>
        <input type="text" name="sabor" required><br>
        <input type="submit" value="Cadastrar">
    </form>
</div>
