<?php echo '<link rel="stylesheet" href="../style.css">'; ?>
<?php
require 'config.inc.php';

// Recebe POST
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $tamanho = $_POST['tamanho'];
    $sabor = $_POST['sabor'];

}else{
        echo "<H2>Envio de dados não permitido</H2>";
}

$sql = "INSERT INTO pizzas (tamanho, sabor) 
VALUES ('$tamanho', '$sabor')";

$inserir = mysqli_query($conexao, $sql);

    if($inserir) {
    echo "<p>Pizza cadastrado com sucesso.</p>";
    echo "<p><a href='?pg=admin/pizza-admin'>Voltar para lista</a></p>";
}else{
    echo "<p>Erro ao cadastrar: " . mysqli_error($conexao) . "</p>";
}
?>
