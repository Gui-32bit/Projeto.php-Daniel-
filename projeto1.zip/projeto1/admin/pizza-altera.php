<?php echo '<link rel="stylesheet" href="../style.css">'; ?>
<?php
require 'config.inc.php';

$id = intval($_POST['id'] ?? 0);
$tamanho = intval($_POST['tamanho'] ?? 0);
$sabor = mysqli_real_escape_string($conexao, $_POST['sabor'] ?? '');


$sql = "UPDATE pizzas SET tamanho=$tamanho, sabor='$sabor' WHERE id=$id";

if(mysqli_query($conexao, $sql)){
    echo "<p>Pizza atualizada com sucesso.</p>";
    echo "<p><a href='?pg=admin/pizza-admin'>Voltar para lista</a></p>";
}else{
    echo "<p>Erro ao atualizar: " . mysqli_error($conexao) . "</p>";
}
?>
