<?php echo '<link rel="stylesheet" href="../style.css">'; ?>
<?php
require 'config.inc.php';

$id = intval($_GET['id'] ?? 0);
$sql = "SELECT * FROM pizzas WHERE id = $id";
$res = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($res);
?>
<div>
    <h2>Alterar Pizza</h2>
    <form action="?pg=admin/pizza-altera" method="post">
        <input type="hidden" name="id" value="<?php echo $dados['id']; ?>">
        <label>Tamanho:</label>
        <input type="number" name="tamanho" value="<?php echo $dados['tamanho']; ?>" required><br>
        <label>Sabor:</label>
        <input type="text" name="sabor" value="<?php echo $dados['sabor']; ?>" required><br>
        <input type="submit" value="Salvar Alterações">
    </form>
</div>
