<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        h3{
            color: white;
        }
    </style>
</head>
<body  style="background-image: url(https://upload.wikimedia.org/wikipedia/commons/9/91/Pizza-3007395.jpg);background-repeat: no-repeat;background-attachment: fixed;background-size: cover;">
<div><?php

    echo "<h1 style='color: rgb(255, 255, 255)';>Bem-vindo!</h1>";