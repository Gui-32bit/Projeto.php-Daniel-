<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php
    echo "<h3>Quem nós somos ?</h3>";
    echo "<p style='color: rgb(255, 230, 0)';>Somos umas das pizzarias de João pessoa com maior avaliação<br>entregamos com rapidez e temos a pizza mais bem avaliada desde de 2010<br>em toda <strong>mangabeira e bancários.</strong><br></p>";
