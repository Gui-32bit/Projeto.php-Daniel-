<?php echo '<link rel="stylesheet" href="style.css">'; ?>
<?php
    echo "<h2>Fale Conosco pelo nosso instagram!</h2>";
?>
    <a href="https://www.instagram.com/guilhermedqn" target="_blank">
        <img class="insta" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png" height="50px">
    </a>
